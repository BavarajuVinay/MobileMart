<?php 

echo "Welcome to php";

?>